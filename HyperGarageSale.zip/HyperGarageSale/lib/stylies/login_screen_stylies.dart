import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class LoginScreenStylies {
  // forgotPassword stylies
  static const TextStyle forgotPasswordStylies = TextStyle(
    color: Colors.pink,
    fontSize: 18,
  );
  // signinSocialStylies
  static const TextStyle signinSocialStylies = TextStyle(
    color: Colors.black,
  );
  // signupButtonTextStylies
  static const TextStyle signupButtonTextStylies = TextStyle(
    color: Colors.white,
    fontSize: 20,
  );
}
