import 'package:flutter/material.dart';

class HomeScreenStylies {
  // appBarUpperTitleStylies stylies
  static const TextStyle appBarUpperTitleStylies = TextStyle(
    color: Colors.white,
    fontWeight: FontWeight.bold,
    fontSize: 16,
  );
}
