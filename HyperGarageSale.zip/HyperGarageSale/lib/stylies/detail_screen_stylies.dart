import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DetailScreenStylies {
  // commpanyTitleStyle
  static const TextStyle commpanyTitleStyle = TextStyle(
    color: Colors.black,
    fontSize: 18,
    fontWeight: FontWeight.w600,
  );
//productModelStyle
  static const TextStyle productModelStyle = TextStyle(
    color: Colors.pink,
  );
//productPriceStyle

  static const TextStyle productPriceStyle = TextStyle(
    color: Colors.black,
    fontSize: 20,
    fontWeight: FontWeight.w600,
  );

//productOldPriceStyle

  static const TextStyle productOldPriceStyle = TextStyle(
    color: Colors.grey,
    fontSize: 16,
    decoration: TextDecoration.lineThrough,
    fontWeight: FontWeight.w600,
  );

  //productFropDownValueStyle
  static const TextStyle productDropDownValueStyle = TextStyle(
    color: Colors.black,
    fontSize: 12,
  );

//buttonTextStyle
  static const TextStyle buttonTextStyle = TextStyle(
    color: Colors.white,
    fontSize: 20,
  );
//descriptionTextStyle
  static const TextStyle descriptionTextStyle = TextStyle(
    fontSize: 18.0,
    fontWeight: FontWeight.w500,
    color: Colors.black,
  );
  //sizeGruideTextStyle
  static const TextStyle sizeGruideTextStyle = TextStyle(
    fontSize: 18.0,
    color: Colors.black,
  );
//youmayalsolikeTextStyle
  static const TextStyle youmayalsolikeTextStyle = TextStyle(
    fontSize: 18.0,
    color: Colors.black,
  );
}
