import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CategoryScreenStylies {
  // categoryAppBarTitleStyle
  static const TextStyle categoryAppBarTitleStyle = TextStyle(
    color: Colors.black,
    fontWeight: FontWeight.bold,
  );
//categoryProductNameStyle
  static const TextStyle categoryProductNameStyle = TextStyle(
    color: Colors.black,
    fontSize: 20,
    fontWeight: FontWeight.w400,
  );
//categoryProductModelStyle
  static const TextStyle categoryProductModelStyle = TextStyle(
    color: Colors.pink,
    fontSize: 14,
  );
}
