import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SignupScreenStylies {
  //signInAgressStyle
  static const TextStyle signInAgressStyle = TextStyle(
    color: Colors.black,
    fontFamily: "NovaFlat",
    fontSize: 16,
  );
  //termsTextStyle
  static const TextStyle termsTextStyle = TextStyle(
    color: Colors.pink,
    fontSize: 16,
  );
//andTextStyle
  static const TextStyle andTextStyle = TextStyle(
    fontSize: 16,
  );
//conditionsOfUseStyle
  static const TextStyle conditionsOfUseStyle = TextStyle(
    fontSize: 16,
    color: Colors.pink,
  );
//signInSocialStyle
  static const TextStyle signInSocialStyle = TextStyle(
    color: Colors.black,
  );
//signUpButtonTextStyle
  static const TextStyle signUpButtonTextStyle = TextStyle(
    color: Colors.black,
    fontSize: 20,
  );
}
