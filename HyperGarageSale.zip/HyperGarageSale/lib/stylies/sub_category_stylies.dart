import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class SubCategoryStylies {
  // subCategoryTitleStyle
  static const TextStyle subCategoryTitleStyle = TextStyle(
    color: Colors.black,
    fontSize: 34,
    fontWeight: FontWeight.bold,
  );

//subCategoryProductItemStyle
  static const TextStyle subCategoryProductItemStyle = TextStyle(
    color: Colors.grey,
  );

  //subCategoryProductItemStyle
  static const TextStyle subCategoryModelNameStyle = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w400,
    color: Colors.grey,
  );
}
