import '../../screens/models/SingleProductModel.dart';

List<SingleProductModel> sigleProductData = [
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6101036512835-2?fmt=jpeg&qlt=90&wid=652&hei=652',
    productModel: 'Action Figures',
    productName: 'Woody Action Figure',
    productOldPrice: 33,
    productPrice: 20,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6101047623483?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Action Figures',
    productName: 'Toy Story Figure',
    productOldPrice: 24,
    productPrice: 11,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/7741055953459?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Gift Book',
    productName: 'Antonios Amazing',
    productOldPrice: 17,
    productPrice: 5,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/7741055953456?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Horizon Book',
    productName: 'Star Wars The High Republic',
    productOldPrice: 19,
    productPrice: 3,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6804058733973?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Cheese Board',
    productName: 'Ratatouille',
    productOldPrice: 49.99,
    productPrice: 10,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6401044616133?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Paper Towel Holder',
    productName: 'Winnie the Pooh',
    productOldPrice: 39.99,
    productPrice: 10,
  ),
];
////////////////////////////// Toys.............
List<SingleProductModel> ToysData = [
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6101036512835-2?fmt=jpeg&qlt=90&wid=652&hei=652',
    productModel: 'Action Figures',
    productName: 'Woody Action Figure',
    productOldPrice: 33,
    productPrice: 20,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6101047623483?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Action Figures',
    productName: 'Toy Story Figure',
    productOldPrice: 24,
    productPrice: 11,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6401056575828?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Cookie Jar',
    productName: 'Jack Skellington',
    productOldPrice: 80,
    productPrice: 65,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/1234105713416-1?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Backpack',
    productName: 'Mickey Mouse Backpack',
    productOldPrice: 21,
    productPrice: 12,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6102036513620?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Car',
    productName: 'Steve Slick Lapage',
    productOldPrice: 8.99,
    productPrice: 2,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6106047623292?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Shield',
    productName: 'Captain America Shield',
    productOldPrice: 25,
    productPrice: 7,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/1230000443273?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Plush',
    productName: 'Small 10 Groot',
    productOldPrice: 23,
    productPrice: 4,
  ),
];
////////////////////////////// Books.............
List<SingleProductModel> BooksData = [
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/7741055953459?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Gift Book',
    productName: 'Antonios Amazing',
    productOldPrice: 17,
    productPrice: 5,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/7741055953456?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Horizon Book',
    productName: 'Star Wars The High Republic',
    productOldPrice: 19,
    productPrice: 3,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/7741055953085?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Baby Book',
    productName: 'Good Night, Farm',
    productOldPrice: 9,
    productPrice: 2,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/7741055953079?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Baby Book',
    productName: 'Peek and Play',
    productOldPrice: 11,
    productPrice: 2,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/7741055953164?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Stories Book',
    productName: 'Disney Junior 5',
    productOldPrice: 14.99,
    productPrice: 2,
  ),
];
///////////////////////////// Tools........
List<SingleProductModel> ToolsData = [
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6804058733973?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Cheese Board',
    productName: 'Ratatouille',
    productOldPrice: 49.99,
    productPrice: 10,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6401044616133?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Paper Towel Holder',
    productName: 'Winnie the Pooh',
    productOldPrice: 39.99,
    productPrice: 10,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6401057806206?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Caddy',
    productName: 'Stitch Utensil',
    productOldPrice: 39.99,
    productPrice: 9.99,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6401056576011?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Measuring Cup',
    productName: 'Mickey Mouse and Friends',
    productOldPrice: 24.99,
    productPrice: 8,
  ),
  SingleProductModel(
    productImage:
        'https://cdn-ssl.s7.disneystore.com/is/image/DisneyShopping/6401057806025?fmt=webp&qlt=70&wid=1304&hei=1304',
    productModel: 'Home Trivet',
    productName: 'Mickey Mouse',
    productOldPrice: 21.99,
    productPrice: 6,
  ),
];
