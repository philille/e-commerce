import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../routes/routes.dart';
import '../../stylies/signup_screen_stylies.dart';
import '../../widgets/my_button_widget.dart';
import '../../widgets/my_textfromfield_widget.dart';
import '../homepage/home_page.dart';
import '../loginScreen/login_screen.dart';

class SignupScreen extends StatelessWidget {
  TextEditingController passwordTextController = TextEditingController();
  TextEditingController emailTextController = TextEditingController();
  final _auth = FirebaseAuth.instance;
  Widget buildTopPart({required BuildContext context}) {
    return Column(
      children: [
        Image.asset(
          "images/sale.png",
          height: 160,
        ),
        reusableTextField(
            "E-mail", Icons.person_outline, false, emailTextController),
        const SizedBox(
          height: 20,
        ),
        reusableTextField(
            "Password", Icons.lock_outlined, true, passwordTextController),
        const SizedBox(
          height: 20,
        ),
        Container(
          margin: EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 10,
          ),
          child: MyButtonWidget(
            onPress: () async {
              FirebaseAuth.instance
                  .createUserWithEmailAndPassword(
                      email: emailTextController.text,
                      password: passwordTextController.text)
                  .then((value) {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => LoginScreen()));
              });
            },
            color: Colors.blueAccent,
            text: "Create an account",
          ),
        ),
        SizedBox(
          height: 10,
        ),
        RichText(
          text: TextSpan(
            text: "By sigining up you agress to our\n\t",
            style: SignupScreenStylies.signInAgressStyle,
            children: <TextSpan>[
              TextSpan(
                text: "Terms\t",
                style: SignupScreenStylies.termsTextStyle,
              ),
              TextSpan(
                text: "and\t",
                style: SignupScreenStylies.andTextStyle,
              ),
              TextSpan(
                text: "Conditions of Use",
                style: SignupScreenStylies.conditionsOfUseStyle,
              ),
            ],
          ),
        )
      ],
    );
  }

  Widget buildSocialButton(
      {required Widget child, required Function onPressed}) {
    return MaterialButton(
      onPressed: () {},
      child: child,
    );
  }

  Widget buildBottomPart() {
    return Container(
      height: 200,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text(
            "Sign up with social medias",
            style: SignupScreenStylies.signInSocialStyle,
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: EdgeInsets.all(10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // facebook social button
                buildSocialButton(
                  onPressed: () {},
                  child: Image.asset(
                    "images/facebook.png",
                    height: 40,
                  ),
                ),

                // google social button
                buildSocialButton(
                  onPressed: () {},
                  child: Image.asset(
                    "images/google.png",
                    height: 40,
                  ),
                ),
                // twitter social button
                buildSocialButton(
                  onPressed: () {},
                  child: Image.asset(
                    "images/twitter.png",
                    height: 40,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      body: SafeArea(
        child: ListView(
          physics: BouncingScrollPhysics(),
          children: [
            buildTopPart(
              context: context,
            ),
            buildBottomPart(),
          ],
        ),
      ),
    );
  }
}
