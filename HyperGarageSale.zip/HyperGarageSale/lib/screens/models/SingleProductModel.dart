class SingleProductModel {
  String productName;
  String productImage;
  String productModel;
  double productPrice;
  double productOldPrice;
  SingleProductModel({
    required this.productImage,
    required this.productModel,
    required this.productName,
    required this.productOldPrice,
    required this.productPrice,
  });
}
