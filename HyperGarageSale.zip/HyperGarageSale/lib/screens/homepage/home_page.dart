import 'package:flutter/material.dart';
import '../../data/home-page-data/home-page-data.dart';
import '../../widgets/singleProduct_widget.dart';
import '../tabbar/tabbar_data.dart';

class HomePage extends StatelessWidget {
  //static SingleProductModel signleProductModel;
  AppBar buildAppBar(BuildContext context) {
    return AppBar(
      bottom: const TabBar(
        labelPadding: EdgeInsets.symmetric(horizontal: 20),
        indicator: BoxDecoration(
          color: Colors.transparent,
        ),
        isScrollable: true,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        unselectedLabelColor: Colors.white,
        labelColor: Colors.yellow,
        tabs: [
          Text("New"),
          Text("Toys"),
          Text("Books"),
          Text("Tools"),
        ],
      ),
      backgroundColor: Colors.blueAccent,
      elevation: 0.0,
      centerTitle: true,
      title: Column(
        children: [
          Image.asset(
            "images/sale_logo.png",
            height: 60,
          ),
        ],
      ),
    );
  }

  Widget buildAdvertismentPlace() {
    return Column(
      children: [
        SizedBox(
          height: 6,
        ),
      ],
    );
  }

  //

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: buildAppBar(context),
        body: TabBarView(
          children: [
            ListView(
              physics: BouncingScrollPhysics(),
              children: [
                buildAdvertismentPlace(),
                Image.asset(
                  "images/new.png",
                  height: 50,
                ),
                Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: 12,
                  ),
                  child: GridView.builder(
                    shrinkWrap: true,
                    primary: true,
                    itemCount: sigleProductData.length,
                    physics: NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.7,
                    ),
                    itemBuilder: (context, index) {
                      var arrivalDataStore = sigleProductData[index];

                      return SingleProductWidget(
                        productImage: arrivalDataStore.productImage,
                        productModel: arrivalDataStore.productModel,
                        productName: arrivalDataStore.productName,
                        productOldPrice: arrivalDataStore.productOldPrice,
                        productPrice: arrivalDataStore.productPrice,
                        onPressed: () {},
                      );
                    },
                  ),
                ),
              ],
            ),
            TabBarBar(
              productData: ToysData,
            ),
            TabBarBar(
              productData: BooksData,
            ),
            TabBarBar(
              productData: ToolsData,
            ),
          ],
        ),
      ),
    );
  }
}
