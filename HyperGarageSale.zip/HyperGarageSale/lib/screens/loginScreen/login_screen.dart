import 'package:flutter/material.dart';
import '../../routes/routes.dart';
import '../../stylies/login_screen_stylies.dart';
import '../../widgets/my_textfromfield_widget.dart';
import '../homepage/home_page.dart';
import '../signup/signup_screen.dart';
import 'package:flutter_svg/flutter_svg.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController passwordTextController = TextEditingController();
  TextEditingController emailTextController = TextEditingController();
  Widget buildTopPart() {
    return Column(
      children: [
        Image.asset(
          "images/sale.png",
          height: 260,
        ),
        Column(
          children: [
            reusableTextField(
                "E-mail", Icons.person_outline, false, emailTextController),
            const SizedBox(
              height: 20,
            ),
            reusableTextField(
                "Password", Icons.lock_outlined, true, passwordTextController),
            const SizedBox(
              height: 20,
            ),
          ],
        ),
        Container(
          margin: EdgeInsets.all(20),
          child: MaterialButton(
            color: Colors.blueAccent,
            height: 45,
            elevation: 0,
            shape: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.circular(5.0),
            ),
            child: Center(
              child: Text(
                "Log in",
                style: LoginScreenStylies.signupButtonTextStylies,
              ),
            ),
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => HomePage()));
            },
          ),
        ),
        SizedBox(
          height: 8,
        ),
      ],
    );
  }

  Widget buildSocialButton({Widget? child, required Function onPressed}) {
    return MaterialButton(
      // shape: OutlineInputBorder(
      //   borderSide: BorderSide(
      //     width: 0,
      //     color: Colors.grey,
      //   ),
      //   borderRadius: BorderRadius.circular(5),
      // ),
      onPressed: () {},
      child: child,
    );
  }

  Widget buildBottomPart({required BuildContext context}) {
    return Container(
      height: 220,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text(
            "Sign up with social medias",
            style: LoginScreenStylies.signinSocialStylies,
          ),
          SizedBox(
            height: 5,
          ),
          Padding(
            padding: EdgeInsets.all(20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                // facebook social button
                buildSocialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => SignupScreen()));
                  },
                  child: Image.asset(
                    "images/facebook.png",
                    height: 40,
                  ),
                ),

                // google social button
                buildSocialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => SignupScreen()));
                  },
                  child: Image.asset(
                    "images/google.png",
                    height: 40,
                  ),
                ),
                // twitter social button
                buildSocialButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => SignupScreen()));
                  },
                  child: Image.asset(
                    "images/twitter.png",
                    height: 40,
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.all(20),
            child: MaterialButton(
              color: Colors.blueAccent,
              height: 45,
              elevation: 0,
              shape: OutlineInputBorder(
                borderSide: BorderSide.none,
                borderRadius: BorderRadius.circular(5.0),
              ),
              child: Center(
                child: Text(
                  "Sign up",
                  style: LoginScreenStylies.signupButtonTextStylies,
                ),
              ),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => SignupScreen()));
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ListView(
            physics: BouncingScrollPhysics(),
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  buildTopPart(),
                  buildBottomPart(context: context),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
